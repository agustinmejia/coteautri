<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <hr>
    <p>Hola, </p>
    <p>Recibimos una solicitud para restablecer tu contraseña de <span style="color:#0088ff;font-weight:bold">Trabajos</span><span style="color:#ff9d00;font-weight:bold">Top</span>. <br>Ingresa el siguiente código para restablecer la contraseña:</p>
    <span style="font-size: 17px; color:#000000;font-weight:bold; border: 2px solid #65b6fd; padding: 10px; border-radius: 10px; background-color: #d6ecfe">179088</span>

    {{-- <p>También puedes cambiar la contraseña directamente.</p> --}}

    <p><b>¿No solicitaste este cambio?</b><br>Si no solicitaste una nueva contraseña, avísanos.</p>
</body>

<style>
    #code {
        
        
    }
</style>
</html>